# CyberCorp Enterprise Security Home Lab

## Project Overview

CyberCorp Enterprise Lab is a multi-segment enterprise cybersecurity environment built on an Ubuntu Linux host with VMware Workstation Pro and pfSense CE. The objective is to design, deploy, secure, monitor, troubleshoot, and document infrastructure similar to a small corporate network.

This repository documents both successful implementation and the troubleshooting performed during deployment. The current milestone establishes the virtual firewall, segmented network architecture, DHCP, an Ubuntu client, routing/NAT, Internet connectivity, and DNS resolution.

## Skills Demonstrated

VMware administration, pfSense firewall administration, network segmentation, IPv4 subnetting, DHCP, routing and NAT, DNS troubleshooting, Linux networking, systematic troubleshooting, evidence collection, and technical documentation.

## Architecture

```mermaid
flowchart TB
 Internet((Internet)) --> NAT["VMware NAT / VMnet8"] --> FW["FW01 - pfSense"]
 FW --> N10["VMnet2 | 192.168.10.0/24 | Server/Lab"]
 FW --> N20["VMnet3 | 192.168.20.0/24 | Users"]
 FW --> N30["VMnet4 | 192.168.30.0/24 | Security"]
 FW --> N40["VMnet5 | 192.168.40.0/24"]
 FW --> N50["VMnet6 | 192.168.50.0/24"]
 N10 --> C["CLIENT01 | Ubuntu | 192.168.10.100 DHCP"]
 N10 -.-> DC["DC01 | Active Directory | Planned"]
 N30 -.-> SOC["SIEM / XDR / NSM | Planned"]
 N50 -.-> K["ATTACK01 | Kali | Planned"]
```

## Firewall Interface Design

| Interface | NIC | Address | Purpose |
|---|---|---|---|
| WAN | em0 | DHCP, observed 172.16.132.128/24 | Upstream Internet |
| LAN | em1 | 192.168.10.1/24 | Primary lab/server network |
| OPT1 | em2 | 192.168.20.1/24 | User network |
| OPT2 | em3 | 192.168.30.1/24 | Security network |
| OPT3 | em4 | 192.168.40.1/24 | Expansion network |
| OPT4 | em5 | 192.168.50.1/24 | Expansion network |

FW01 was configured with multiple VMware virtual adapters to support the segmented architecture.

![FW01 VMware adapters](evidence/17-fw01-multi-nic-vmware.png)

The pfSense console confirmed the multi-interface addressing design.

![pfSense interfaces](evidence/18-pfsense-interface-dhcp-process.png)

## pfSense Installation

FW01 was deployed as the central firewall and router. The installer used ZFS and GPT for the virtual disk.

![ZFS and GPT](evidence/03-pfsense-zfs-gpt.png)

The stable pfSense CE 2.8.1 release was selected instead of the available beta release.

![Stable pfSense release](evidence/06-pfsense-stable-version.png)

The virtual disk installation was then confirmed.

![Disk confirmation](evidence/05-pfsense-disk-confirmation.png)

## LAN Configuration

An initial installation screen showed a 192.168.1.1/24 LAN. The interface was later reconfigured to match the CyberCorp addressing plan.

![Initial LAN](evidence/01-pfsense-initial-lan.png)

The implemented LAN is:

```text
Network: 192.168.10.0/24
Gateway / FW01: 192.168.10.1
```

![CyberCorp LAN](evidence/02-pfsense-cybercorp-lan.png)

The console configuration confirms the static address and /24 subnet.

![LAN subnet](evidence/15-pfsense-lan-subnet.png)

IPv6 DHCP was not configured during this IPv4-focused phase.

![IPv6 disabled](evidence/14-pfsense-ipv6-disabled.png)

## DHCP Configuration

DHCP was enabled on the LAN with this scope:

```text
192.168.10.100 - 192.168.10.199
Default gateway: 192.168.10.1
```

![DHCP enable](evidence/12-pfsense-dhcp-enable.png)

The DHCP configuration was also inspected from the pfSense shell during troubleshooting.

![DHCP inspection](evidence/16-pfsense-dhcp-config-inspection.png)

The final console configuration saved the LAN address and DHCP settings and made the pfSense WebConfigurator available through HTTPS at `192.168.10.1`.

![Final LAN DHCP configuration](evidence/23-pfsense-final-lan-dhcp.png)

## CLIENT01 Deployment

CLIENT01 was created as an Ubuntu virtual machine from an ISO stored in the CyberCorpLab project directory.

![CLIENT01 creation](evidence/21-client01-vm-iso.png)

### Initial Network Failure

During Ubuntu setup, CLIENT01 initially displayed **Activation of network connection failed**.

![Connection failure](evidence/19-client01-connection-failure.png)

The Ubuntu live session also showed the failed connection.

![Live session failure](evidence/20-client01-live-session-failure.png)

This became an important troubleshooting exercise instead of being bypassed.

## Troubleshooting Process

The investigation followed the network path in order:

1. Verify VMware NIC attachment and virtual network.
2. Verify pfSense interface assignments.
3. Verify LAN address and subnet.
4. Verify DHCP configuration.
5. Check DHCP-related processes.
6. Inspect the CLIENT01 interface and lease.
7. Test the default gateway.
8. Test a public IP address.
9. Test DNS resolution.

During client troubleshooting, `sudo dhclient -v` returned `command not found`. The interface was therefore inspected directly with:

```bash
ip addr
```

CLIENT01 had successfully received `192.168.10.100/24` on `ens33`.

![CLIENT01 DHCP lease](evidence/10-client01-dhcp-address.png)

This address is inside the configured `.100-.199` pool and demonstrated that DHCP communication between CLIENT01 and FW01 was working.

## Connectivity Validation

### 1. DHCP — PASS

Expected: `192.168.10.100-192.168.10.199`

Observed: `192.168.10.100/24`

### 2. Default Gateway — PASS

```bash
ping -c 4 192.168.10.1
```

Four packets were transmitted and four returned with 0% packet loss.

![Gateway test](evidence/09-client01-gateway.png)

### 3. Internet Routing and NAT — PASS

```bash
ping -c 4 8.8.8.8
```

Four responses were received with 0% packet loss.

![Internet test](evidence/08-client01-internet.png)

This confirmed the working path from CLIENT01 through FW01 to the upstream network.

### 4. DNS — PASS

```bash
ping -c 4 google.com
```

The hostname resolved successfully and all four responses returned.

![DNS test](evidence/07-client01-dns-internet.png)

## Validation Summary

| Test | Observed | Result |
|---|---|---|
| DHCP | CLIENT01 received 192.168.10.100/24 | PASS |
| Gateway | 192.168.10.1, 0% packet loss | PASS |
| Internet | 8.8.8.8, 0% packet loss | PASS |
| DNS | google.com resolved and responded | PASS |

```text
CLIENT01 192.168.10.100
          |
          v
CyberCorp LAN 192.168.10.0/24
          |
          v
FW01 192.168.10.1
          |
     Routing / NAT
          |
          v
VMware WAN / NAT
          |
          v
       Internet
       /      \
  8.8.8.8   google.com
    PASS       PASS
```

## Key Troubleshooting Lesson

The initial connection failure demonstrated why network problems should be isolated layer by layer. A client connectivity problem can originate from the virtual NIC, DHCP, subnet configuration, default gateway, firewall interface, NAT, upstream routing, or DNS.

Instead of changing several components at once, each dependency was validated individually. This established a known-good network baseline that can be reused as CyberCorp grows.

## Current Milestone

**Core Network Foundation: COMPLETE**

The lab currently has a working VMware environment, FW01 pfSense firewall, multi-interface network design, functioning `192.168.10.0/24` LAN, DHCP scope, Ubuntu CLIENT01, gateway connectivity, Internet connectivity, DNS resolution, and documented troubleshooting evidence.

## Next Phase

The next phase will deploy Windows Server and Active Directory. Planned work includes DC01, DNS, organizational units, users, groups, Group Policy, and domain-joined Windows endpoints.

Later phases will introduce Splunk, Wazuh, Security Onion, OpenVAS, Velociraptor, and Kali Linux to support SOC monitoring, vulnerability management, incident response, threat hunting, detection engineering, and purple-team exercises.

## Repository Structure

```text
CyberCorp-Enterprise-Lab/
├── README.md
├── evidence/
│   ├── README.md
│   └── screenshots...
├── diagrams/
├── documentation/
├── scripts/
└── incident-reports/
```

## Status

This is an active portfolio project. The README and evidence set will continue to grow as each enterprise infrastructure and security milestone is implemented and validated.
